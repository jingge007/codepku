$(function () {
    $('.center_box .item').on('click', function () {
        $(this).addClass('selected').siblings('span').removeClass('selected');
    })

    $('.tearcher_item').on('click', function () {
        $(this).addClass('selected').siblings('span').removeClass('selected');
    })
})